var searchData=
[
  ['userinfo',['UserInfo',['../class_user_info.html',1,'']]]
];
