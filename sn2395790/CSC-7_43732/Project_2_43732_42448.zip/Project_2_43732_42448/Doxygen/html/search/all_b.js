var searchData=
[
  ['name',['name',['../structinfo.html#a8cb03e18cc1040a9bd15b661ccce2c87',1,'info::name()'],['../structhighscore.html#a457d3d144e3fd13d9d2d52a8d34b6d71',1,'highscore::name()']]]
];
