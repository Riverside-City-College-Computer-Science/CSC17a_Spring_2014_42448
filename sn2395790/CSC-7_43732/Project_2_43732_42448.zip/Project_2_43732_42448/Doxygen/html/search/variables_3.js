var searchData=
[
  ['score',['score',['../structhighscore.html#a51e3313d14eb74e063e67f349da7b37b',1,'highscore']]]
];
